package com.example.passowrdgenerator;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.AttributeSet;

import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


public class app extends AppCompatActivity {

    static int nr_letters;

    Button generate_button;
    ImageButton copy_button;

    EditText password_result;
    EditText number_of_letters;

    CheckBox upper_letters;
    CheckBox lower_letters;
    CheckBox numbers_included;
    CheckBox symbols_included;

    /*@Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

            setID();
            generate();


    }*/

    public void setID(){

        generate_button=findViewById(R.id.button_generate);
        copy_button=findViewById(R.id.copy_button);///Image Button

        password_result=findViewById(R.id.Password_result);
        number_of_letters=findViewById(R.id.input_number_letters);

        upper_letters=findViewById(R.id.checkBox_upper_letters);
        lower_letters=findViewById(R.id.checkBox_lower_letters);

        numbers_included=findViewById(R.id.checkBox_number);
        symbols_included=findViewById(R.id.checkBox_symbols);

    }



    boolean check_for_requirements_checkboxes(){

        int checked_boxes=0;

        if(upper_letters.isChecked())
            checked_boxes++;

        if(lower_letters.isChecked())
            checked_boxes++;

        if(numbers_included.isChecked())
            checked_boxes++;

        if(symbols_included.isChecked())
            checked_boxes++;

        if(checked_boxes==0)
            return false;

        return true;
    }

    boolean check_for_requirements()
    {

        ///first case--- number of letters is not filled
        if(number_of_letters.getText().toString().isEmpty())
        {
            Toast.makeText(getApplicationContext(), "Number of letters required", Toast.LENGTH_SHORT).show();
            return false;
        }
        else
            nr_letters=Integer.parseInt(number_of_letters.getText().toString());

        if(!check_for_requirements_checkboxes())
        {
            Toast.makeText(getApplicationContext(), "Minimum one option is required", Toast.LENGTH_SHORT).show();
            return false;
        }


        return true;
    }

    public void generate(){


        generate_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                boolean status= check_for_requirements();

                if(status)
                    password_result.setText("car");
            }
        });



    }





}
